package banco;

import java.sql.*;

import javax.swing.JOptionPane;

public class AlterarBanco {
	
	public static void main(String[] args) {
		try {					realizaOperacao();		} 
		catch (Exception e) {	e.printStackTrace();	}    }
	private static void realizaOperacao() throws Exception {
		Connection cn = conectaBanco.openDB2();
		Statement st = null;        
		try {
			st = cn.createStatement();
			String nome = JOptionPane.showInputDialog(
			"Digite o nome do aluno a ser alterado");
			PesquisaNome consulta = new PesquisaNome();
			Aluno alterado = PesquisaNome.consultarNomeCompleto(nome);
			if(consulta!=null) {
				int resp = JOptionPane.showConfirmDialog(null, 
						"Confirma a alteração do aluno: \n" + alterado);
				if (resp==0) {			alterarAluno(alterado);				}
				else {
					JOptionPane.showMessageDialog(null, "O aluno: " 
							+ alterado.getNome() + " NÃO foi alterado");   
				}   } 
			else
				JOptionPane.showMessageDialog(null, "O aluno: " 
						+ alterado.getNome() + " NÃO foi encontrado"); 		}        
		catch (SQLException e) {
			throw new Exception("Falha ao acessar base de dados.\n" 
					+ e.getMessage());
		} finally {			st.close();			cn.close();		}	}
	
	public static Aluno alterarAluno(Aluno alterado) throws SQLException {
		Connection con = conectaBanco.openDB2();		
		PreparedStatement pstm = con.prepareStatement("UPDATE alunos SET "
				+ " nome=?, telefone=?, nota=? WHERE alunoId=?");
		String nome = JOptionPane.showInputDialog("Digite o novo Nome: ");
		String telefone = JOptionPane.showInputDialog("Digite o telefone: ");
		double nota = Double.parseDouble(JOptionPane.showInputDialog("Digite a nota: "));	
		pstm.setString(1, nome);		pstm.setString(2, telefone);
		pstm.setDouble(3, nota);		pstm.setInt(4, alterado.getKey());
		Aluno aposAlteracao = new Aluno(alterado.getKey(), nome, telefone, nota);
		pstm.execute();
		JOptionPane.showMessageDialog(null, "Aluno alterado com sucesso!!!");
		return aposAlteracao;	}	}

