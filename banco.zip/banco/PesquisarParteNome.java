package banco;

import java.sql.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class PesquisarParteNome {
	public static void main(String[] args) throws Exception	{
		List<Aluno> alunos = new PesquisarParteNome()
				.consultar(JOptionPane.showInputDialog(
						"Digite o nome do aluno a ser consultado:"));
		System.out.println("Data e hora da consulta: " + lerHora());
		for (Aluno aluno : alunos) {
			System.out.println(aluno);			
		}		
	}	
	public List<Aluno> consultar(String nome) throws Exception {				
		String queryCmd = "select * from alunos where "
				+ "nome like ? ";				
		List<Aluno> alunos = new ArrayList<Aluno>();				
		Connection con = null;				
		try {
			con = conectaBanco.openDB2();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ps1.setString(1, (nome != null ? '%'+nome.trim()+'%' : ""));					
			ResultSet rs = ps1.executeQuery();		
			if(!rs.next()) {
				System.out.println("Não foi localizado nenhum aluno com nome: " + nome);
				System.exit(0);
			}
			while(rs.next()) {						
				int id = rs.getInt("alunoId");
				String nomeAluno = rs.getString("nome");
				double nota = rs.getDouble("nota");
				String telefone = rs.getString("telefone");						
				Aluno novo = new Aluno(id, nomeAluno, telefone, nota);
				alunos.add(novo);						
			}
		} catch (SQLException e) {
			throw new Exception(e); // encapsula excecao original
		} finally {
			conectaBanco.closeDB2();	
		}		
		return alunos;
	}	
	public static String lerHora() {
		DateFormat dia = new SimpleDateFormat("dd/MM/YYYY");
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		return dia.format(date) + " - "  + dateFormat.format(date);
	}
}
