package banco;

import java.awt.HeadlessException;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;

public class PesquisaNome {

	
	static Connection con=null;	
	public static void main(String[] args) throws HeadlessException, Exception {
		Aluno aluno = new PesquisaNome().consultarNomeCompleto(
			JOptionPane.showInputDialog("Digite o nome completo do aluno a ser consultado:"));
				System.out.println("Data e hora da consulta: " + lerHora());
				if(aluno!=null)
					System.out.println(aluno);

	}
	
	static Aluno consultarNomeCompleto(String nome) throws Exception {
		Aluno novo = null;
		String queryCmd = "select * from alunos where "
				+ "nome like ? ";				
		try {
			con = conectaBanco.openDB2();
			PreparedStatement ps1 = con.prepareStatement(queryCmd);
			ps1.setString(1, (nome != null ? nome.trim() : ""));			
			ResultSet rs = ps1.executeQuery();			
			if(rs.next()) {				
				int id = rs.getInt("alunoId");
				String nomeAluno = rs.getString("nome");
				double nota = rs.getDouble("nota");
				String telefone = rs.getString("telefone");				
				novo = new Aluno(id, nome, telefone, nota);				
			}
			else
				System.out.println(nome + " não encontrado.");
		} catch (SQLException e) {
			throw new Exception(e); // encapsula excecao original
		} finally {
			conectaBanco.closeDB2();	
		}		
		return novo;
	}	
	public static String lerHora() {
		DateFormat dia = new SimpleDateFormat("dd/MM/YYYY");
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date date = new Date();
		return dia.format(date) + " - "  + dateFormat.format(date);
	}
}

