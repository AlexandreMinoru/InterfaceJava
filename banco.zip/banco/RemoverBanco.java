package banco;

import java.sql.*;

import javax.swing.JOptionPane;

public class RemoverBanco {
	public static void main(String[] args) {
		try {
			realizaOperacao();
		} catch (Exception e) {
			e.printStackTrace();
		}    }
	
	private static void realizaOperacao() throws Exception {
		Connection cn = null;
		Statement st = null;        
		try {
			cn = conectaBanco.openDB2();
			st = cn.createStatement();
			String nome = JOptionPane.showInputDialog(
			"Digite o nome do aluno a ser excluído: ");
			PesquisaNome consulta = new PesquisaNome();
			Aluno excluido = consulta.consultarNomeCompleto(nome);
			if(excluido==null) {
				JOptionPane.showMessageDialog(null, "O aluno: " 
						+ nome + " NÂO foi localizado na tabela de Alunos!!!");
				return;
			}
			int resp = JOptionPane.showConfirmDialog(null, 
			"Confirma a exclusão do aluno: \n" + excluido);
			if (resp==0) {
				st.executeUpdate("DELETE FROM Alunos WHERE alunoId='" 
				+ excluido.getKey() + "'");
				JOptionPane.showMessageDialog(null, "O aluno: " 
				+ excluido.getNome() + " Foi excluído com sucesso!!!");
			}
			else
				JOptionPane.showMessageDialog(null, "O aluno: " 
				+ excluido.getNome() + " NÃO foi excluído");            
		} catch (SQLException e) {
			throw new Exception("Falha ao acessar base de dados.\n" 
			+ e.getMessage());
		} finally {
			st.close();
			cn.close();
		}
	}
}
